"""Framework-agnostic helpers to serve SSR shells, import maps, and WS bridges."""
