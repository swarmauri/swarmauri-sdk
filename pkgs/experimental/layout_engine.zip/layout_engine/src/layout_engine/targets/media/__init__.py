"""Media exporters: HTML, SVG, PDF (placeholder), and code emission."""
