"""Lesson 16: table router bindings.

This lesson highlights how REST routers are stored on the API instance so
handlers can be discovered and composed without inspecting the app.
The router registry is the preferred pattern because it centralizes routing
metadata with the API configuration.
"""

from tigrbl import Base, TigrblRouter
from tigrbl.engine.shortcuts import mem
from tigrbl.orm.mixins import GUIDPk
from tigrbl.types import Column, String


def test_table_binding_attaches_rest_router():
    """REST routers returned by include_model are stored on the API namespace."""

    class Widget(Base, GUIDPk):
        __tablename__ = "lesson_table_router"
        __allow_unmapped__ = True

        name = Column(String, nullable=False)

    router = TigrblRouter(engine=mem(async_=False))

    _, rest_router = router.include_table(Widget)

    assert rest_router is not None
    assert router.routers[Widget.__name__] is rest_router


def test_router_registry_tracks_model_alias():
    """The router registry can be queried by model name for routing metadata."""

    class Widget(Base, GUIDPk):
        __tablename__ = "lesson_table_router_registry"
        __allow_unmapped__ = True

        name = Column(String, nullable=False)

    router = TigrblRouter(engine=mem(async_=False))

    _, rest_router = router.include_table(Widget)

    assert Widget.__name__ in router.routers
    assert router.routers[Widget.__name__] is rest_router
