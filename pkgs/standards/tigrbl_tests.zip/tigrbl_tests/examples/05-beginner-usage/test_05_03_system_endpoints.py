from __future__ import annotations

import inspect

import httpx
import pytest

from examples._support import pick_unique_port, start_uvicorn, stop_uvicorn
from tigrbl import Base, TigrblApp
from tigrbl.engine.shortcuts import mem
from tigrbl.orm.mixins import GUIDPk
from tigrbl.types import Column, String


@pytest.mark.asyncio
async def test_system_endpoints_are_available() -> None:
    class Widget(Base, GUIDPk):
        __tablename__ = "lesson_system_widget"
        __allow_unmapped__ = True

        name = Column(String, nullable=False)

    app = TigrblApp(engine=mem(async_=False))
    app.include_table(Widget)
    init_result = app.initialize()
    if inspect.isawaitable(init_result):
        await init_result

    app.attach_diagnostics(prefix="", app=app)

    port = pick_unique_port()
    base_url, server, task = await start_uvicorn(app, port=port)
    try:
        async with httpx.AsyncClient(base_url=base_url, timeout=10.0) as client:
            health = await client.get("/healthz")
            kernel = await client.get("/kernelz")
        assert health.status_code == 200
        assert health.json()["ok"] is True
        assert kernel.status_code == 200
        assert "Widget" in kernel.json()
    finally:
        await stop_uvicorn(server, task)
