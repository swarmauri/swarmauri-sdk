# Extras Keys for no_requirements

This template set does not use an EXTRAS section.
