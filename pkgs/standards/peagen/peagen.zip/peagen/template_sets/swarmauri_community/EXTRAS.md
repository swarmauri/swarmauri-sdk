# Extras Keys for swarmauri_community
This template set recognizes the following EXTRAS keys:

- RESOURCE_KIND
- PURPOSE
- DESCRIPTION
- REQUIREMENTS
- DEPENDENCIES
- AUTHORS
- BASE_FILE
- EXTERNAL_DOC_FILES
- MIXIN_FILES
- BASE_CLASS
- MIXINS
- EXAMPLES
