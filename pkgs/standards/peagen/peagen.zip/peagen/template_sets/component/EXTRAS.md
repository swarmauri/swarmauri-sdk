# Extras Keys for component

This template set does not use an EXTRAS section.
