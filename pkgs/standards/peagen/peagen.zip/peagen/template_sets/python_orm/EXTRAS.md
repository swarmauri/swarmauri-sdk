# Extras Keys for python_orm

This template set recognizes the following EXTRAS keys:

- RESOURCE_KIND
- PURPOSE
- DESCRIPTION
- REQUIREMENTS
- HAS_CHILDREN
- CHILD_NAME
- FIELD_DEFINITIONS
- DEPENDENCIES
