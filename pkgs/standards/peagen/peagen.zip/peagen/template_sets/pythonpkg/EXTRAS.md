# Extras Keys for pythonpkg

This template set recognizes the following EXTRAS keys:

- AUTHORS
- PURPOSE
- DESCRIPTION
- REQUIREMENTS
- DEPENDENCIES
- BASE_FILE
- EXTERNAL_DOC_FILES
- MIXIN_FILES
- BASE_CLASS
- MIXINS
- RESOURCE_KIND
- EXAMPLES
