# Extras Keys for cpp_python_pkg

This template set recognizes the following EXTRAS keys:

- AUTHORS
- PURPOSE
- DESCRIPTION
- REQUIREMENTS
- DEPENDENCIES
