# Extras Keys for python_api_gw

This template set recognizes the following EXTRAS keys:

- RESOURCE_KIND
- PURPOSE
- DESCRIPTION
- REQUIREMENTS
- DEPENDENCIES
