"""Security-related ORM models."""

from .public_key import PublicKeyModel

PublicKey = PublicKeyModel
