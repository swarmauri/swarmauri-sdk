"""Seat assignment ops – authoritative local seat ledger (quantity is on subscription item)."""
from __future__ import annotations
from typing import Optional
from tigrbl.types import UUID
from tigrbl_billing.tables.subscription_item import SubscriptionItem
from tigrbl_billing.tables.seat_allocation import SeatAllocation, SeatState
from contextlib import contextmanager
from typing import Any, Tuple
from tigrbl.types import Session

def _acquire(model, op_ctx) -> Tuple[Session, Any]:
    alias = getattr(op_ctx, 'alias', None) if op_ctx is not None else None
    db, release = model.acquire(op_alias=alias)
    return (db, release)

@contextmanager
def _session_for(model, op_ctx):
    db, release = _acquire(model, op_ctx)
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        release()

def seat_assign(op_ctx, engine_ctx, schema_ctx, *, subscription_item_id: UUID, subject_ref: str, role: Optional[str]=None) -> dict:
    with _session_for(SeatAllocation, op_ctx) as db:
        if hasattr(db, 'get') and db.get(SubscriptionItem, subscription_item_id) is None:
            raise ValueError('subscription item not found')
        obj = None
        if hasattr(db, 'query'):
            obj = db.query(SeatAllocation).filter(SeatAllocation.subscription_item_id == subscription_item_id, SeatAllocation.subject_ref == subject_ref).one_or_none()
        if obj is None:
            obj = SeatAllocation(subscription_item_id=subscription_item_id, subject_ref=subject_ref, role=role, state=SeatState.ACTIVE)
        else:
            obj.state = SeatState.ACTIVE
            obj.role = role
        db.add(obj)
        db.flush()
        return {'seat_allocation_id': str(obj.id), 'state': obj.state.value}

def seat_release(op_ctx, engine_ctx, schema_ctx, *, subscription_item_id: UUID, subject_ref: str) -> dict:
    with _session_for(SeatAllocation, op_ctx) as db:
        obj = None
        if hasattr(db, 'query'):
            obj = db.query(SeatAllocation).filter(SeatAllocation.subscription_item_id == subscription_item_id, SeatAllocation.subject_ref == subject_ref).one_or_none()
        if obj is None:
            raise ValueError('seat not found')
        obj.state = SeatState.RELEASED
        db.add(obj)
        db.flush()
        return {'seat_allocation_id': str(obj.id), 'state': obj.state.value}

def seat_suspend(op_ctx, engine_ctx, schema_ctx, *, subscription_item_id: UUID, subject_ref: str) -> dict:
    with _session_for(SeatAllocation, op_ctx) as db:
        obj = None
        if hasattr(db, 'query'):
            obj = db.query(SeatAllocation).filter(SeatAllocation.subscription_item_id == subscription_item_id, SeatAllocation.subject_ref == subject_ref).one_or_none()
        if obj is None:
            raise ValueError('seat not found')
        obj.state = SeatState.SUSPENDED
        db.add(obj)
        db.flush()
        return {'seat_allocation_id': str(obj.id), 'state': obj.state.value}