"""Invoice ops – draft/finalize/void/uncollectible (DB-first, Stripe outside)."""
from __future__ import annotations
from typing import Optional, Sequence, Mapping
from tigrbl.types import UUID
from tigrbl_billing.tables.invoice import Invoice, InvoiceStatus, CollectionMethod as InvoiceCollectionMethod
from tigrbl_billing.tables.invoice_line_item import InvoiceLineItem
from tigrbl_billing.tables.subscription_item import SubscriptionItem
from contextlib import contextmanager
from typing import Any, Tuple
from tigrbl.types import Session

def _acquire(model, op_ctx) -> Tuple[Session, Any]:
    alias = getattr(op_ctx, 'alias', None) if op_ctx is not None else None
    db, release = model.acquire(op_alias=alias)
    return (db, release)

@contextmanager
def _session_for(model, op_ctx):
    db, release = _acquire(model, op_ctx)
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        release()

def finalize_invoice(op_ctx, engine_ctx, schema_ctx, *, invoice_id: UUID, line_items: Optional[Sequence[Mapping[str, object]]]=None) -> dict:
    """Finalize an invoice: freeze line items and compute totals."""
    with _session_for(Invoice, op_ctx) as db:
        inv = db.get(Invoice, invoice_id)
        if inv is None:
            raise ValueError('invoice not found')
        total = 0
        if line_items:
            if hasattr(db, 'query'):
                for li in db.query(InvoiceLineItem).filter(InvoiceLineItem.invoice_id == invoice_id).all():
                    db.delete(li)
            for li in line_items:
                ilo = InvoiceLineItem(invoice_id=invoice_id, subscription_item_id=li.get('subscription_item_id'), price_id=li.get('price_id'), description=li.get('description'), quantity=li.get('quantity'), unit_amount=li.get('unit_amount'), amount=li['amount'], proration=bool(li.get('proration', False)), tax_details=li.get('tax_details') or {}, metadata=li.get('metadata') or {})
                db.add(ilo)
                db.flush()
        if hasattr(db, 'query'):
            for li in db.query(InvoiceLineItem).filter(InvoiceLineItem.invoice_id == invoice_id).all():
                total += int(li.amount or 0)
        inv.total = inv.amount_due = inv.amount_remaining = total
        inv.status = InvoiceStatus.OPEN
        db.add(inv)
        db.flush()
        return {'invoice_id': str(inv.id), 'status': inv.status.value, 'total': inv.total}

def void_invoice(op_ctx, engine_ctx, schema_ctx, *, invoice_id: UUID) -> dict:
    with _session_for(Invoice, op_ctx) as db:
        inv = db.get(Invoice, invoice_id)
        if inv is None:
            raise ValueError('invoice not found')
        inv.status = InvoiceStatus.VOID
        db.add(inv)
        db.flush()
        return {'invoice_id': str(inv.id), 'status': inv.status.value}

def mark_invoice_uncollectible(op_ctx, engine_ctx, schema_ctx, *, invoice_id: UUID) -> dict:
    with _session_for(Invoice, op_ctx) as db:
        inv = db.get(Invoice, invoice_id)
        if inv is None:
            raise ValueError('invoice not found')
        inv.status = InvoiceStatus.UNCOLLECTIBLE
        db.add(inv)
        db.flush()
        return {'invoice_id': str(inv.id), 'status': inv.status.value}