"""Customer ops: create/link and payment method attach (DB-only)."""
from __future__ import annotations
from typing import Optional
from tigrbl_billing.tables.customer import Customer, TaxExemptStatus
from contextlib import contextmanager
from typing import Any, Tuple
from tigrbl.types import Session

def _acquire(model, op_ctx) -> Tuple[Session, Any]:
    alias = getattr(op_ctx, 'alias', None) if op_ctx is not None else None
    db, release = model.acquire(op_alias=alias)
    return (db, release)

@contextmanager
def _session_for(model, op_ctx):
    db, release = _acquire(model, op_ctx)
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        release()

def create_or_link_customer(op_ctx, engine_ctx, schema_ctx, *, email: Optional[str]=None, name: Optional[str]=None, stripe_customer_id: Optional[str]=None, default_payment_method_ref: Optional[str]=None, tax_exempt: str='none', metadata: Optional[dict]=None, active: bool=True) -> dict:
    """Create a customer or link to an existing Stripe customer by stripe_customer_id."""
    metadata = metadata or {}
    status = TaxExemptStatus[tax_exempt.upper()]
    with _session_for(Customer, op_ctx) as db:
        obj = None
        if stripe_customer_id and hasattr(db, 'query'):
            obj = db.query(Customer).filter(Customer.stripe_customer_id == stripe_customer_id).one_or_none()
        if obj is None:
            obj = Customer(email=email, name=name, stripe_customer_id=stripe_customer_id, default_payment_method_ref=default_payment_method_ref, tax_exempt=status, metadata=metadata, active=active)
        else:
            obj.email = email or obj.email
            obj.name = name or obj.name
            obj.default_payment_method_ref = default_payment_method_ref or obj.default_payment_method_ref
            obj.tax_exempt = status
            obj.metadata = metadata
            obj.active = active
        db.add(obj)
        db.flush()
        return {'customer_id': str(obj.id), 'stripe_customer_id': obj.stripe_customer_id, 'email': obj.email}

def attach_payment_method(op_ctx, engine_ctx, schema_ctx, *, customer_id, payment_method_ref: str) -> dict:
    """Update local default payment method reference (no remote call)."""
    with _session_for(Customer, op_ctx) as db:
        obj = db.get(Customer, customer_id)
        if obj is None:
            raise ValueError('customer not found')
        obj.default_payment_method_ref = payment_method_ref
        db.add(obj)
        db.flush()
        return {'customer_id': str(obj.id), 'default_payment_method_ref': obj.default_payment_method_ref}