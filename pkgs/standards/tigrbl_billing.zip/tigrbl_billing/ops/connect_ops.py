"""Connect ops – split rules & transfers (DB-first)."""
from __future__ import annotations
from typing import Optional
from tigrbl.types import UUID
from tigrbl_billing.tables.split_rule import SplitRule, SplitMode
from tigrbl_billing.tables.transfer import Transfer
from tigrbl_billing.tables.application_fee import ApplicationFee
from contextlib import contextmanager
from typing import Any, Tuple
from tigrbl.types import Session

def _acquire(model, op_ctx) -> Tuple[Session, Any]:
    alias = getattr(op_ctx, 'alias', None) if op_ctx is not None else None
    db, release = model.acquire(op_alias=alias)
    return (db, release)

@contextmanager
def _session_for(model, op_ctx):
    db, release = _acquire(model, op_ctx)
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        release()

def refund_application_fee(op_ctx, engine_ctx, schema_ctx, *, application_fee_id: UUID) -> dict:
    with _session_for(ApplicationFee, op_ctx) as db:
        af = db.get(ApplicationFee, application_fee_id)
        if af is None:
            raise ValueError('application_fee not found')
        af.refunded = True
        db.add(af)
        db.flush()
        return {'application_fee_id': str(af.id), 'refunded': af.refunded}