"""Subscription lifecycle ops (DB-first)."""
from __future__ import annotations
from typing import Optional, Sequence, Mapping
from tigrbl.types import UUID
from tigrbl_billing.tables.subscription import Subscription, SubscriptionStatus, CollectionMethod
from tigrbl_billing.tables.subscription_item import SubscriptionItem
from tigrbl_billing.tables.price import Price
from contextlib import contextmanager
from typing import Any, Tuple
from tigrbl.types import Session

def _acquire(model, op_ctx) -> Tuple[Session, Any]:
    alias = getattr(op_ctx, 'alias', None) if op_ctx is not None else None
    db, release = model.acquire(op_alias=alias)
    return (db, release)

@contextmanager
def _session_for(model, op_ctx):
    db, release = _acquire(model, op_ctx)
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        release()

def start_subscription(op_ctx, engine_ctx, schema_ctx, *, customer_id: UUID, items: Sequence[Mapping[str, object]], collection_method: str='charge_automatically', days_until_due: Optional[int]=None, trial_end: Optional[object]=None, stripe_subscription_id: Optional[str]=None, metadata: Optional[dict]=None) -> dict:
    """Start a subscription with one or more items (licensed or metered)."""
    metadata = metadata or {}
    cm = CollectionMethod[collection_method.upper()]
    with _session_for(Subscription, op_ctx) as db:
        sub = Subscription(customer_id=customer_id, status=SubscriptionStatus.ACTIVE if not trial_end else SubscriptionStatus.TRIALING, cancel_at_period_end=False, current_period_start=None, current_period_end=None, trial_end=trial_end, collection_method=cm, days_until_due=days_until_due, stripe_subscription_id=stripe_subscription_id, metadata=metadata)
        db.add(sub)
        db.flush()
        created_items = []
        for it in items:
            price_id = it['price_id']
            quantity = it.get('quantity')
            if hasattr(db, 'get') and db.get(Price, price_id) is None:
                raise ValueError('price not found')
            si = SubscriptionItem(subscription_id=sub.id, price_id=price_id, quantity=quantity, stripe_subscription_item_id=it.get('stripe_subscription_item_id'), metadata=it.get('metadata') or {})
            db.add(si)
            db.flush()
            created_items.append({'subscription_item_id': str(si.id), 'price_id': str(si.price_id), 'quantity': si.quantity})
        return {'subscription_id': str(sub.id), 'items': created_items}

def cancel_subscription(op_ctx, engine_ctx, schema_ctx, *, subscription_id: UUID, cancel_at_period_end: bool=True) -> dict:
    with _session_for(Subscription, op_ctx) as db:
        sub = db.get(Subscription, subscription_id)
        if sub is None:
            raise ValueError('subscription not found')
        if cancel_at_period_end:
            sub.cancel_at_period_end = True
        else:
            sub.status = SubscriptionStatus.CANCELED
        db.add(sub)
        db.flush()
        return {'subscription_id': str(sub.id), 'status': sub.status.value, 'cancel_at_period_end': sub.cancel_at_period_end}

def pause_subscription(op_ctx, engine_ctx, schema_ctx, *, subscription_id: UUID) -> dict:
    with _session_for(Subscription, op_ctx) as db:
        sub = db.get(Subscription, subscription_id)
        if sub is None:
            raise ValueError('subscription not found')
        sub.status = SubscriptionStatus.PAST_DUE
        db.add(sub)
        db.flush()
        return {'subscription_id': str(sub.id), 'status': sub.status.value}

def resume_subscription(op_ctx, engine_ctx, schema_ctx, *, subscription_id: UUID) -> dict:
    with _session_for(Subscription, op_ctx) as db:
        sub = db.get(Subscription, subscription_id)
        if sub is None:
            raise ValueError('subscription not found')
        sub.status = SubscriptionStatus.ACTIVE
        sub.cancel_at_period_end = False
        db.add(sub)
        db.flush()
        return {'subscription_id': str(sub.id), 'status': sub.status.value}

def trial_start(op_ctx, engine_ctx, schema_ctx, *, subscription_id: UUID, trial_end: object) -> dict:
    with _session_for(Subscription, op_ctx) as db:
        sub = db.get(Subscription, subscription_id)
        if sub is None:
            raise ValueError('subscription not found')
        sub.trial_end = trial_end
        sub.status = SubscriptionStatus.TRIALING
        db.add(sub)
        db.flush()
        return {'subscription_id': str(sub.id), 'trial_end': str(trial_end)}

def trial_end(op_ctx, engine_ctx, schema_ctx, *, subscription_id: UUID) -> dict:
    with _session_for(Subscription, op_ctx) as db:
        sub = db.get(Subscription, subscription_id)
        if sub is None:
            raise ValueError('subscription not found')
        sub.trial_end = None
        sub.status = SubscriptionStatus.ACTIVE
        db.add(sub)
        db.flush()
        return {'subscription_id': str(sub.id), 'status': sub.status.value}

def proration_preview(op_ctx, engine_ctx, schema_ctx, *, subscription_id: UUID, proposed_items: Sequence[Mapping[str, object]]) -> dict:
    """DB-only placeholder: returns structured preview echo (actual amounts require Stripe calculation)."""
    return {'subscription_id': str(subscription_id), 'preview': list(proposed_items)}