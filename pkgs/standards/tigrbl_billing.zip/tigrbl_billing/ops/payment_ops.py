"""Payment ops – create/capture/cancel payment intents, create refund (DB-only)."""
from __future__ import annotations
from typing import Optional
from tigrbl.types import UUID
from tigrbl_billing.tables.payment_intent import PaymentIntent, PaymentIntentStatus, CaptureMethod
from tigrbl_billing.tables.refund import Refund, RefundStatus
from contextlib import contextmanager
from typing import Any, Tuple
from tigrbl.types import Session

def _acquire(model, op_ctx) -> Tuple[Session, Any]:
    alias = getattr(op_ctx, 'alias', None) if op_ctx is not None else None
    db, release = model.acquire(op_alias=alias)
    return (db, release)

@contextmanager
def _session_for(model, op_ctx):
    db, release = _acquire(model, op_ctx)
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        release()

def capture_payment_intent(op_ctx, engine_ctx, schema_ctx, *, payment_intent_id: UUID) -> dict:
    with _session_for(PaymentIntent, op_ctx) as db:
        pi = db.get(PaymentIntent, payment_intent_id)
        if pi is None:
            raise ValueError('payment_intent not found')
        pi.status = PaymentIntentStatus.SUCCEEDED
        db.add(pi)
        db.flush()
        return {'payment_intent_id': str(pi.id), 'status': pi.status.value}

def cancel_payment_intent(op_ctx, engine_ctx, schema_ctx, *, payment_intent_id: UUID) -> dict:
    with _session_for(PaymentIntent, op_ctx) as db:
        pi = db.get(PaymentIntent, payment_intent_id)
        if pi is None:
            raise ValueError('payment_intent not found')
        pi.status = PaymentIntentStatus.CANCELED
        db.add(pi)
        db.flush()
        return {'payment_intent_id': str(pi.id), 'status': pi.status.value}