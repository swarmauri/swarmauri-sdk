"""Response binding helpers (placeholder)."""

from __future__ import annotations
from typing import Any, Dict


def bind(collected: Dict[str, Any]) -> None:  # pragma: no cover - trivial
    """Bind collected response configuration. Currently a no-op."""
    return None


__all__ = ["bind"]
