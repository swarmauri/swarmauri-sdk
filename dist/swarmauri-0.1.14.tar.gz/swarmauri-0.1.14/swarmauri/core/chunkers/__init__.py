# -*- coding: utf-8 -*-
"""
Created on Wed Feb 28 20:35:27 2024

@author: bigman
"""

