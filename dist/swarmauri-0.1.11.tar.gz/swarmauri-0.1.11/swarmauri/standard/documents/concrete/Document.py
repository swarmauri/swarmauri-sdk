from swarmauri.standard.documents.base.DocumentBase import DocumentBase

class Document(DocumentBase):
    pass
    
        
